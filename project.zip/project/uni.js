// Read search parameter from URL when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Get search parameter from URL
    const urlParams = new URLSearchParams(window.location.search);
    const searchTerm = urlParams.get('search');
    
    if (searchTerm) {
        // Set the search input value
        const searchInput = document.getElementById('universitySearch');
        if (searchInput) {
            searchInput.value = searchTerm;
            
            // Trigger the search
            filterUniversities();
            
            // Scroll to results
            setTimeout(() => {
                document.querySelector('.filter-section').scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });
            }, 300);
        }
    }
});

// Get all university cards
const universityCards = document.querySelectorAll('.university-card');
const searchInput = document.getElementById('universitySearch');
const regionFilter = document.getElementById('regionFilter');
const majorFilter = document.getElementById('majorFilter');
const typeFilter = document.getElementById('typeFilter');
const sortBy = document.getElementById('sortBy');
const resultCount = document.getElementById('resultCount');
const noResults = document.getElementById('noResults');
const activeFiltersDiv = document.getElementById('activeFilters');

// Update result count on page load
updateResultCount();

// Search functionality
searchInput.addEventListener('input', filterUniversities);

// Filter change events
regionFilter.addEventListener('change', filterUniversities);
majorFilter.addEventListener('change', filterUniversities);
typeFilter.addEventListener('change', filterUniversities);
sortBy.addEventListener('change', sortUniversities);

function filterUniversities() {
    const searchTerm = searchInput.value.toLowerCase();
    const selectedRegion = regionFilter.value;
    const selectedMajor = majorFilter.value;
    const selectedType = typeFilter.value;
    
    let visibleCount = 0;
    
    universityCards.forEach(card => {
        const uniName = card.querySelector('h3').textContent.toLowerCase();
        const uniRegion = card.getAttribute('data-region');
        const uniMajor = card.getAttribute('data-major');
        const uniType = card.getAttribute('data-type');
        
        const matchesSearch = uniName.includes(searchTerm);
        const matchesRegion = !selectedRegion || uniRegion === selectedRegion;
        const matchesMajor = !selectedMajor || uniMajor === selectedMajor;
        const matchesType = !selectedType || uniType === selectedType;
        
        if (matchesSearch && matchesRegion && matchesMajor && matchesType) {
            card.style.display = 'block';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });
    
    updateResultCount(visibleCount);
    updateActiveFilters();
    
    // Show/hide no results message
    if (visibleCount === 0) {
        noResults.style.display = 'block';
    } else {
        noResults.style.display = 'none';
    }
}

function sortUniversities() {
    const sortValue = sortBy.value;
    const grid = document.getElementById('universitiesGrid');
    const cardsArray = Array.from(universityCards);
    
    cardsArray.sort((a, b) => {
        if (sortValue === 'name') {
            const nameA = a.querySelector('h3').textContent;
            const nameB = b.querySelector('h3').textContent;
            return nameA.localeCompare(nameB);
        } else if (sortValue === 'region') {
            const regionA = a.getAttribute('data-region');
            const regionB = b.getAttribute('data-region');
            return regionA.localeCompare(regionB);
        }
        return 0;
    });
    
    // Re-append sorted cards
    cardsArray.forEach(card => grid.appendChild(card));
}

function updateResultCount(count) {
    if (count === undefined) {
        count = universityCards.length;
    }
    resultCount.textContent = count;
}

function updateActiveFilters() {
    activeFiltersDiv.innerHTML = '';
    
    const filters = [
        { element: regionFilter, label: 'Region' },
        { element: majorFilter, label: 'Major' },
        { element: typeFilter, label: 'Type' }
    ];
    
    filters.forEach(filter => {
        if (filter.element.value) {
            const selectedText = filter.element.options[filter.element.selectedIndex].text;
            const tag = document.createElement('div');
            tag.className = 'filter-tag';
            tag.innerHTML = `
                ${filter.label}: ${selectedText}
                <button onclick="clearFilter('${filter.element.id}')">×</button>
            `;
            activeFiltersDiv.appendChild(tag);
        }
    });
}

function clearFilter(filterId) {
    document.getElementById(filterId).value = '';
    filterUniversities();
}

// Handle URL parameters (from homepage filters)
window.addEventListener('load', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const major = urlParams.get('major');
    
    if (major) {
        // Set the major filter based on URL parameter
        const majorValue = major.toLowerCase().replace(/\s+/g, '-');
        majorFilter.value = majorValue;
        filterUniversities();
    }
});
